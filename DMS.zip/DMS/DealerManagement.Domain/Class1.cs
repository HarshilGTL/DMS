﻿namespace DealerManagement.Domain
{
    public class Class1
    {

    }
}
