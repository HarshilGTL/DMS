﻿namespace DealerManagement.Infrastructure
{
    public class Class1
    {

    }
}
