﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YourProject.Pages
{
    [Authorize]
    public class IndexModel : PageModel
    {
        public string UserName { get; set; }

        public void OnGet()
        {
            UserName = User.Identity.Name;
        }
    }
}
