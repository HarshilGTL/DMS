========================================
Dealer Management System (DMS)
========================================
1) Overview

This repository contains a cloud-native Dealer Management System (DMS) built with .NET Core and Razor Pages, deployed on Azure, and integrated with Azure Active Directory (Azure AD) for authentication. It also includes a CI/CD pipeline using Azure DevOps and Infrastructure-as-Code (Bicep/Terraform).

2) Features

	Authentication & Security: Azure AD, MFA, and SSO

3) Frontend: .NET Core Razor Pages

4) Backend: .NET Core Web API

5) Database: Azure SQL & Cosmos DB

6) Deployment: Azure App Service

	CI/CD: Azure DevOps Pipeline

7) Infrastructure: Terraform for Azure Resource Deployment

8) Prerequisites

	Ensure you have the following installed:

	.NET SDK (>=6.0)

	Azure CLI

	Git

	Terraform (if using Terraform for infrastructure)

9) Setup Instructions

	9.1. Clone Repository
		
	   git clone https://github.com/HarshilGTL/DMS.git
    
	   cd dms

    9.2. Install Dependencies

       dotnet restore

    9.3. Configure Azure AD Authentication

     Update appsettings.json with your Azure AD credentials:

  "DMSAzureAd": {
   "Instance": "https://xxxx.microsoftonline.com/",
   "TenantId": "DMS-tenant-id",
   "ClientId": "DMS-client-id",
   "CallbackPath": "/signin-oidc"
   }

   9.4. Run the Application Locally

      dotnet run

     Visit https://localhost:7001 in your browser.

   Deployment

   9.5. Deploy to Azure (Manual)

   Login to Azure:

   az login

   Create a Resource Group:

   az group create --name dms-rg --location westeurope

   Deploy application to Azure App Service:

   dotnet publish -c Release -o ./publish
   az webapp deployment source config-zip --resource-group dms-rg --name dms-app-service --src ./publish.zip

  CI/CD Setup (Azure DevOps)

  9.6. Configure Azure DevOps Pipeline

  Create a new Azure DevOps pipeline and use the provided azure-pipelines.yml file.

  Run the pipeline with the following stages:

  Build - Installs dependencies and compiles the project.

 Deploy - Deploys the app to Azure App Service.

 Infrastructure-as-Code (IaC)

 9.7. Deploy with Terraform

 If using Terraform:

 terraform init
 terraform apply

10) Monitoring & Logging

Enable Application Insights for real-time monitoring:

az monitor app-insights component create --app dms-insights --resource-group dms-rg --location westeurope
